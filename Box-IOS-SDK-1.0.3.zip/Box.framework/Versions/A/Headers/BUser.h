//
//  BUser.h
//  Box
//
//  Created by Kévin LEFEBVRE on 08/09/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Regexp.h"

/**
* Define a Box user 
*/
@interface BUser : NSObject

@property (nonatomic) NSString * civility;
@property (nonatomic) NSString * lastname ;
@property (nonatomic) NSString * firstname ;
@property (nonatomic) NSString * email ;
@property (nonatomic) NSString * address ;
@property (nonatomic) NSString * zipCode ;
@property (nonatomic) NSString * country ;
@property (nonatomic) NSString * birthday ;
@property (nonatomic) NSString * loyalty ;
@property (nonatomic) NSString * deskPhone ;
@property (nonatomic) NSString * mobilePhone ;
@property (nonatomic) NSString * reglement ;
@property (nonatomic) NSString * newletter ;
@property (nonatomic) NSString * nickName ;
@property (nonatomic) NSString * state ;
@property (nonatomic) NSString * pinterest_board ;
@property (nonatomic) NSString * authenticate ;

- (NSString *)getCivility;
- (NSString *)getLastname;
- (NSString *)getFirstname;
- (NSString *)getEmail;
- (NSString *)getAddress;
- (NSString *)getZipCode;
- (NSString *)getCountry;
- (NSString *)getBirthday;
- (NSString *)getLoyalty;
- (NSString *)getDeskPhone;
- (NSString *)getMobilePhone;
- (NSString *)getReglement;
- (NSString *)getNewletter;
- (NSString *)getNickName;
- (NSString *)getState;
- (NSString *)getPinterest_board;
- (NSString *)getAuthenticate;

- (void)setCivility:(NSString *)value;
- (void)setLastname:(NSString *)value;
- (void)setFirstname:(NSString *)value;
- (void)setEmail:(NSString *)value;
- (void)setAddress:(NSString *)value;
- (void)setZipCode:(NSString *)value;
- (void)setCountry:(NSString *)value;
- (void)setBirthday:(NSString *)value;
- (void)setLoyalty:(NSString *)value;
- (void)setDeskPhone:(NSString *)value;
- (void)setMobilePhone:(NSString *)value;
- (void)setReglement:(BOOL)value;
- (void)setNewletter:(BOOL)value;
- (void)setNickName:(NSString *)value;
- (void)setState:(NSString *)value;
- (void)setPinterest_board:(NSString *)value;
- (void)setAuthenticate:(BOOL)value;

-(id)initWithCivilty:(NSString *)civility withLastName:(NSString *)lastName withFirstName:(NSString *)firstName withEmail:(NSString *)email withAddress:(NSString *)address withZipCode:(NSString *)zipCode withCountry:(NSString *)country withBirthday:(NSString *)birthday withLoyalty:(NSString *)loyalty withDeskPhone:(NSString *)deskPhone withMobilePhone:(NSString *)mobilePhone withReglement:(BOOL)reglement withNewLetter:(BOOL)newLetter withNickName:(NSString *)nickName withState:(NSString *)state withPinterest_board:(NSString *)pinterest_board withAuthenticate:(BOOL)authenticate;
-(id)init;

@end
