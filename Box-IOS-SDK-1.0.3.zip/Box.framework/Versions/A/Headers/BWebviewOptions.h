//
//  BWebviewOptions.h
//  Box
//
//  Created by Matthieu Karolewicz on 16/02/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 *  Contains all webview customization options
 */
@interface BWebviewOptions : NSObject

- (void)setNavigationBarTitleVisible:(BOOL)value;
- (BOOL)isNavigationBarTitleVisible;
- (void)setBackButtonHidden:(BOOL)value;
- (BOOL)isBackButtonHidden;
- (void)setNavigationBarHidden:(BOOL)value;
- (BOOL)isNavigationBarHidden;
- (void)setNavigationBarBackgroundColor:(UIColor *)color;
- (UIColor *)navigationBarBackgroundColor;
- (void)setNavigationBarButtonsColor:(UIColor *)color;
- (UIColor *)navigationBarButtonsColor;
- (void)setNavigationBarTitleColor:(UIColor *)color;
- (UIColor *)navigationBarTitleColor;
- (void)setNavigationBarOpaque:(BOOL)value;
- (BOOL)isNavigationBarOpaque;
- (void)setNavigationBarBackButton:(UIImage *)image;
- (UIImage *)navigationBarBackButton;
- (void)setNavigationBarActionButton:(UIImage *)image;
- (UIImage *)navigationBarActionButton;
- (void) setNavigationLoadingBarColor:(UIColor *)color;
- (UIColor *) navigationLoadingBarColor;

@end
