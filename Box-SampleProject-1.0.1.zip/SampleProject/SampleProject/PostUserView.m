//
//  BannerView.m
//  Box
//
//  Created by Kévin LEFEBVRE on 13/04/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#define XScale [[UIScreen mainScreen] bounds].size.width / 320.0f
#define YScale [[UIScreen mainScreen] bounds].size.height / 568.0f

#import "PostUserView.h"

@implementation PostUserView

-(id) initWithOperation:(NSString *)operation withApiKey:(NSString *) apikey{
	self = [super init];
	
	_apiKey = apikey;
	_campaignID = operation;
	[self initialize];
	
	return self;
}

- (void) initialize{
	
	/****************************************
	 * BUILD VIEW
	 ***************************************/
	
	int _width  = [[UIScreen mainScreen] bounds].size.width ;
	int _height = [[UIScreen mainScreen] bounds].size.height ;
	
	CGRect	_rectView= CGRectMake(0,0, _width, _height);
	[self setFrame:_rectView];
	
	self.backgroundColor =[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0];
	
	_title = [[UITextView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, _width, _height *.1)];
	[_title addObserver:self forKeyPath:@"contentSize" options:(NSKeyValueObservingOptionNew) context:NULL];
	
	_title.text = @"Preregistered user integration";
	_title.backgroundColor = [UIColor whiteColor];
	_title.textColor = [UIColor darkGrayColor];
	_title.editable = NO;
	_title.textAlignment = NSTextAlignmentCenter;
	_title.font = [UIFont boldSystemFontOfSize:XScale * 20];
	
	[self addSubview:_title];
	
	UITapGestureRecognizer *tapRec = [[UITapGestureRecognizer alloc]
									  initWithTarget:self action:@selector(tap:)];
	[self addGestureRecognizer: tapRec];
	
	UITextView * firstNameLabel = [[UITextView alloc] initWithFrame:CGRectMake(0 , _height *.13 ,_width , _height * 0.07)];
	_firstName = [[UITextView alloc] initWithFrame:CGRectMake(_width * .2,  firstNameLabel.frame.origin.y + firstNameLabel.frame.size.height + 5 * YScale ,_width *.6, _height * 0.08)];
	[self createInput:firstNameLabel withInputText:_firstName withLabelText:@"FirstName"];
	
	UITextView * lastNameLabel = [[UITextView alloc] initWithFrame:CGRectMake(0 , _firstName.frame.origin.y + _firstName.frame.size.height + 10 * YScale ,_width , _height * 0.07)];
	_lastName = [[UITextView alloc] initWithFrame:CGRectMake(_width * .2,  lastNameLabel.frame.origin.y + lastNameLabel.frame.size.height + 5 * YScale ,_width *.6, _height * 0.08)];
	[self createInput:lastNameLabel withInputText:_lastName withLabelText:@"Lastname"];
	
	UITextView * emailLabel = [[UITextView alloc] initWithFrame:CGRectMake(0 ,_lastName.frame.origin.y + _lastName.frame.size.height + 10 * YScale ,_width , _height * 0.07)];
	_email = [[UITextView alloc] initWithFrame:CGRectMake(_width * .2,  emailLabel.frame.origin.y + emailLabel.frame.size.height + 5 * YScale ,_width *.6, _height * 0.08)];
	[self createInput:emailLabel withInputText:_email withLabelText:@"Email"];
	
	_submit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[_submit addTarget:self action:@selector(onClickSubmit:) forControlEvents:UIControlEventTouchUpInside];
	[_submit setFrame:CGRectMake(_width * .2, _email.frame.origin.y + _email.frame.size.height +  (25 * YScale), _width * .6 ,  _height * 0.08)];
	_submit.backgroundColor = [UIColor whiteColor];
	[_submit setTitle:@"Submit" forState:UIControlStateNormal];
	[_submit setTitleColor:[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0] forState:UIControlStateNormal];
	_submit.titleLabel.font = [UIFont systemFontOfSize: 20 * XScale];
	[self addSubview:_submit];
	
	UIButton * returnButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	returnButton.backgroundColor = [UIColor clearColor];
	[returnButton addTarget:self action:@selector(onClickReturnButton:) forControlEvents:UIControlEventTouchUpInside];
	[returnButton setFrame:CGRectMake(_width * 0.25,_height * 0.9 ,_width * 0.5, _height * 0.1)];
	[returnButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	returnButton.titleLabel.font = [UIFont systemFontOfSize: 24 * XScale];
	[returnButton setTitle:@"Return" forState:UIControlStateNormal];
	[self addSubview:returnButton];
	
}

/****************************************
 * BOX SDK INTEGRATION
 ***************************************/

-(void) onClickSubmit:(UIButton*)sender{
	
	if(_firstName.text.length == 0){
		NSLog(@"Error : no valid firstName");
		return;
	}
	
	if(_lastName.text.length == 0){
		NSLog(@"Error : no valid lastName");
		return;
	}
	
	if(_email.text.length == 0){
		NSLog(@"Error : no valid email");
		return;
	}
	
	//Create a empty box user
	_user = [[BUser alloc]init];
	
	
	//set the values user from the form
	@try {
		[_user setFirstname:_firstName.text];
	}@catch(NSException * e){
		NSLog(@"Error : no valid firstName");
		return;
	}
	
	@try {
		[_user setLastname:_lastName.text];
	}@catch(NSException * e){
		NSLog(@"Error : no valid lastName");
		return;
	}
	
	@try {
		[_user setEmail:_email.text];
	}@catch(NSException * e){
		NSLog(@"Error : no valid email");
		return;
	}
	
	if(_apiKey.length == 0){
		NSLog(@"To get your apiKey contact us at contact@adictiz.com");
		return;
	}
		
	 //register the user for a specified campaign
	[Box postUserForm:_apiKey withCampaignId:_campaignID withBoxUser:_user withDelegate:self];
	
}

/****************************************
 * BOX SDK CALLBACK
 ***************************************/

- (void)onPostUserFormFailure:(NSString *)error {
	NSLog(@"onPostUserFormFailure - %@", error);
}

- (void)onPostUserFormSuccess:(NSString *)userId{
	NSLog(@"onPostUserFormSuccess - %@", userId);
	
	//Calling a campaign with a box user permit to skip the register form
	[Box showCampaign:_campaignID withBoxUser:_user];
	
}

//NOT USED
- (void)onGetCampaignsListSuccess:(NSString *)response {
}

- (void)onGetCampaignsListFailure:(NSString *)error {
	NSLog(@"onGetCampaignsListFailure - %@", error);
}

-(void)onPostPictureResult:(bool)response{
	NSLog(@" get pict list : success %d", response);
}

-(void)onGetPicturesListFailure:(NSString *)error{
	NSLog(@"onGetPicturesListFailure - %@", error);
}

/****************************************
 * BUILD VIEW (METHOD)
 ***************************************/

-(void)tap:(UITapGestureRecognizer *)tapRec{
	[self endEditing: YES];
}

-(void) createInput:(UITextView *)label withInputText:(UITextView *)input withLabelText:(NSString *)textLabel {
	
	label.text = textLabel;
	label.editable = NO;
	label.textColor = [UIColor whiteColor];
	label.textAlignment = NSTextAlignmentCenter;
	label.font = [UIFont boldSystemFontOfSize:18 * XScale];
	label.backgroundColor = [UIColor clearColor];
	[self addSubview:label];
	
	input.backgroundColor = [UIColor whiteColor];
	
	input.font = [UIFont boldSystemFontOfSize:18 * YScale];
	[input.layer setBorderColor:[[[UIColor grayColor] colorWithAlphaComponent: 0.5] CGColor]];
	[input.layer setBorderWidth: 2.0];
	input.layer.cornerRadius = 5;
	input.clipsToBounds = YES;
	[self addSubview:input];
	
}

-(void)onClickReturnButton:(UIButton *) sender{
	[_title removeObserver:self forKeyPath:@"contentSize"];
	[self removeFromSuperview];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	UITextView *tv = object;
	CGFloat topCorrect = ([tv bounds].size.height - [tv contentSize].height * [tv zoomScale])/2.0;
	topCorrect = ( topCorrect < 0.0 ? 0.0 : topCorrect );
	tv.contentOffset = (CGPoint){.x = 0, .y = -topCorrect};
}

@end
