//
//  BannersListView.h
//  Box
//
//  Created by Kévin LEFEBVRE on 13/04/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import "AppDelegate.h"
#import <Box/Box.h>

@interface BannersListView : UIView

@property UITextView * title;

- (id) init;
- (void) initialize;

@end
