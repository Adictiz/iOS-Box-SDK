//
//  BannersListView.m
//  Box
//
//  Created by Kévin LEFEBVRE on 13/04/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#define XScale [[UIScreen mainScreen] bounds].size.width / 320.0f
#define YScale [[UIScreen mainScreen] bounds].size.height / 568.0f

#import "BannersListView.h"

@implementation BannersListView

-(id) init{
	self = [super init];
	[self initialize];
	return self;
}

- (void) initialize {
	
	/****************************************
	 * BUILD VIEW
	 ***************************************/
	
	int _width  = [[UIScreen mainScreen] bounds].size.width ;
	int _height = [[UIScreen mainScreen] bounds].size.height ;
	
	CGRect	_rectView= CGRectMake(0,0, _width, _height);
	[self setFrame:_rectView];
	
	self.backgroundColor =[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0];
	
	_title = [[UITextView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, _width, _height *.1)];
	[_title addObserver:self forKeyPath:@"contentSize" options:(NSKeyValueObservingOptionNew) context:NULL];
	_title.text = @"Banner Wall Integration";
	_title.backgroundColor = [UIColor whiteColor];
	_title.textColor = [UIColor darkGrayColor];
	_title.editable = NO;
	_title.textAlignment = NSTextAlignmentCenter;
	_title.font = [UIFont boldSystemFontOfSize:XScale * 24];
	[self addSubview:_title];
	
	UITextView * label = [[UITextView alloc] initWithFrame:CGRectMake(0, _height * 0.13, _width, _height *.1)];
	label.text = @"Banner Wall";
	label.editable = NO;
	label.textColor = [UIColor whiteColor];
	label.textAlignment = NSTextAlignmentCenter;
	label.font = [UIFont boldSystemFontOfSize:22 * XScale];
	label.backgroundColor = [UIColor clearColor];
	[self addSubview:label];
	
	UIButton * returnButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	returnButton.backgroundColor = [UIColor clearColor];
	[returnButton addTarget:self action:@selector(onClickReturnButton:) forControlEvents:UIControlEventTouchUpInside];
	[returnButton setFrame:CGRectMake(_width * 0.25,_height * 0.9 ,_width * 0.5, _height * 0.1)];
	[returnButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	returnButton.titleLabel.font = [UIFont systemFontOfSize: 24 * XScale];
	[returnButton setTitle:@"Return" forState:UIControlStateNormal];
	[self addSubview:returnButton];
	
	/****************************************
	 * BOX SDK INTEGRATION
	 ***************************************/
	
	//Displaying a wall of banners
	UIView * view = [Box getCampaignsListViewWithWidth:_width height:_height * 0.5];
	view.backgroundColor = [UIColor clearColor];
	view.center = CGPointMake(0, label.frame.origin.y + label.frame.size.height + 10 * YScale);
	[self addSubview:view];
}

/****************************************
 * BUILD VIEW (METHOD)
 ***************************************/

-(void)onClickReturnButton:(UIButton *) sender{
	[_title removeObserver:self forKeyPath:@"contentSize"];
	[self removeFromSuperview];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	UITextView *tv = object;
	CGFloat topCorrect = ([tv bounds].size.height - [tv contentSize].height * [tv zoomScale])/2.0;
	topCorrect = ( topCorrect < 0.0 ? 0.0 : topCorrect );
	tv.contentOffset = (CGPoint){.x = 0, .y = -topCorrect};
}

@end
