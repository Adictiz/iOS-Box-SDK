//
//  AppDelegate.h
//  SampleProject
//
//  Created by Kévin LEFEBVRE on 01/12/2015.
//  Copyright © 2015 Kévin LEFEBVRE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

