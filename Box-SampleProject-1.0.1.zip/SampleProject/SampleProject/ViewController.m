//
//  ViewController.m
//  SampleProject
//
//  Created by Kévin LEFEBVRE on 01/12/2015.
//  Copyright © 2015 Kévin LEFEBVRE. All rights reserved.
//

#define XScale [[UIScreen mainScreen] bounds].size.width / 320.0f
#define YScale [[UIScreen mainScreen] bounds].size.height / 568.0f

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	
	/****************************************
	 * To get your mediaKey and your apiKey contact us at contact@adictiz.com
	 ***************************************/
	
	_mediakey = @"o99jfyypiz";
	_apikey = @"";
		
	/****************************************
	 * BUILD VIEW
	 ***************************************/
	
	self.view.backgroundColor =[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0];
	
	int _width  = [[UIScreen mainScreen] bounds].size.width ;
	int _height = [[UIScreen mainScreen] bounds].size.height ;
	
	UITextView * _title = [[UITextView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, _width, _height *.1)];
	[_title addObserver:self forKeyPath:@"contentSize" options:(NSKeyValueObservingOptionNew) context:NULL];
	
	_title.text = @"Sample Project";
	_title.backgroundColor = [UIColor whiteColor];
	_title.textColor = [UIColor darkGrayColor];
	_title.editable = NO;
	_title.textAlignment = NSTextAlignmentCenter;
	_title.font = [UIFont boldSystemFontOfSize:XScale * 24];
	[self.view addSubview:_title];
	
	UITextView * _labelShowCampaign = [[UITextView alloc] initWithFrame:CGRectMake(0, _height * .13,_width, _height * 0.07)];
	_buttonShowCampaign = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[self createElementWithLabel:_labelShowCampaign withButton:_buttonShowCampaign withTextLabel:@"Simple Integration :"];
	
	UITextView * _labelShowUserPost = [[UITextView alloc] initWithFrame:CGRectMake(0,  _buttonShowCampaign.frame.origin.y + _buttonShowCampaign.frame.size.height +  15 * YScale ,_width, _height * 0.07)];
	_buttonShowUserPost = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[self createElementWithLabel:_labelShowUserPost withButton:_buttonShowUserPost withTextLabel:@"Preregistered User Integration :" ];
	
	UITextView * _labelShowBanners = [[UITextView alloc] initWithFrame:CGRectMake(0,  _buttonShowUserPost.frame.origin.y + _buttonShowUserPost.frame.size.height +  15 * YScale ,_width, _height * 0.07)];
	_buttonShowBanners = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[self createElementWithLabel:_labelShowBanners withButton:_buttonShowBanners withTextLabel:@"Simple Banner Integration :" ];
	
	UITextView * _labelShowBannersList =[[UITextView alloc] initWithFrame:CGRectMake(0,  _buttonShowBanners.frame.origin.y + _buttonShowBanners.frame.size.height +  15 * YScale ,_width, _height * 0.07)];
	_buttonShowBannersList = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[self createElementWithLabel:_labelShowBannersList withButton:_buttonShowBannersList withTextLabel:@"Banners Wall Integration :" ];
	
	/****************************************
	 * BOX SDK INTEGRATION
	 ***************************************/
	
	_isReady = NO;
	
	// Displaying log
	[Box setDebugMode:YES];
	
	// Box SDK Initialization
	[Box initialize:_mediakey];
	
	// Customizing the navigation bar
	BWebviewOptions *options = [[BWebviewOptions alloc] init];
	[options setNavigationBarHidden:false];
	[options setNavigationBarTitleColor:[UIColor whiteColor]];
	[options setNavigationLoadingBarColor:[UIColor whiteColor]];
	[options setNavigationBarButtonsColor:[UIColor whiteColor]];
	[options setNavigationBarBackgroundColor:[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0]];
	[Box setWebviewOptions:options];
	
	// Retrieving Box campaigns list
	[Box getCampaignsList:self];
}

/****************************************
 * BOX SDK CALLBACKS
 ***************************************/

- (void)onGetCampaignsListSuccess:(NSString *)response {
	
	// Parsing the response and retrieving the first live campaign
	NSData *data = [response dataUsingEncoding:NSUTF8StringEncoding];
	id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
	
	int i ;
	int length = [json count];
	
	for(i = 0 ;i < length; i++){
		if([[[json objectAtIndex:i] objectForKey:@"status"]  isEqual: @"live"]){
			_campaignID =  [[json objectAtIndex:i] objectForKey:@"id"];
			_isReady = YES ;
			break;
		}
	}
	
	if(!_isReady)
		NSLog(@"No live campaign  was found");
}

//NOT USED
- (void)onGetCampaignsListFailure:(NSString *)error {
	NSLog(@"onGetCampaignsListFailure - %@", error);
}

- (void)onPostUserFormFailure:(NSString *)error {
	NSLog(@"onPostUserFormFailure - %@", error);
}

- (void)onPostUserFormSuccess:(NSString *)userId{
	NSLog(@"onPostUserFormSuccess - %@", userId);
}

-(void)onPostPictureResult:(bool)response{
	NSLog(@" get pict list : success %d", response);
}

-(void)onGetPicturesListFailure:(NSString *)error{
	NSLog(@"onGetPicturesListFailure - %@", error);
}

/****************************************
 * BUILD VIEW (METHODS)
 ***************************************/

-(void) createElementWithLabel:(UITextView *)label withButton:(UIButton *)button withTextLabel:(NSString *)textLabel  {
	
	int _width  = [[UIScreen mainScreen] bounds].size.width ;
	int _height = [[UIScreen mainScreen] bounds].size.height ;
	
	label.text = textLabel;
	label.editable = NO;
	label.textColor = [UIColor whiteColor];
	label.textAlignment = NSTextAlignmentCenter;
	label.font = [UIFont boldSystemFontOfSize:18 * XScale];
	label.backgroundColor = [UIColor clearColor];
	[self.view addSubview:label];
	
	[button addTarget:self action:@selector(onClick:) forControlEvents:UIControlEventTouchUpInside];
	[button setFrame:CGRectMake(_width *.25 , label.frame.origin.y + label.frame.size.height +   (5 * YScale), _width * 0.5 , _height * 0.07)];
	button.backgroundColor = [UIColor whiteColor];
	[button setTitle:@"Click Here !" forState:UIControlStateNormal];
	[button setTitleColor:[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0] forState:UIControlStateNormal];
	button.titleLabel.font = [UIFont systemFontOfSize: 20 * XScale];
	[self.view addSubview:button];
	
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	UITextView *tv = object;
	CGFloat topCorrect = ([tv bounds].size.height - [tv contentSize].height * [tv zoomScale])/2.0;
	topCorrect = ( topCorrect < 0.0 ? 0.0 : topCorrect );
	tv.contentOffset = (CGPoint){.x = 0, .y = -topCorrect};
}

-(void) onClick:(UIButton*)sender{
	
	if(!_isReady){
		NSLog(@" the Box SDK is not ready yet");
		return;
	}
	
	if(sender == _buttonShowCampaign){
		[Box showCampaign:_campaignID];
	}
	else if(sender == _buttonShowBanners){
		UIView * view = [[BannerView  alloc]init];
		[self.view addSubview:view];
	}
	else if(sender == _buttonShowBannersList){
		UIView * view = [[BannersListView  alloc]init];
		[self.view addSubview:view];
	}
	else if(sender == _buttonShowUserPost){
		UIView * view = [[PostUserView  alloc]initWithOperation:_campaignID withApiKey:_apikey];
		[self.view addSubview:view];
	}
}

@end
