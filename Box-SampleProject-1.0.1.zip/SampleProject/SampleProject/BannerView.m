//
//  BannerView.m
//  Box
//
//  Created by Kévin LEFEBVRE on 13/04/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#define XScale [[UIScreen mainScreen] bounds].size.width / 320.0f
#define YScale [[UIScreen mainScreen] bounds].size.height / 568.0f

#import "BannerView.h"

@implementation BannerView

-(id) init{
	self = [super init];
	[self initialize];
	return self;
}

- (void) initialize{
	
	/****************************************
	 * BUILD VIEW
	 ***************************************/
	
	int _width  = [[UIScreen mainScreen] bounds].size.width ;
	int _height = [[UIScreen mainScreen] bounds].size.height ;
	
	CGRect	_rectView= CGRectMake(0,0, _width, _height);
	[self setFrame:_rectView];
	
	self.backgroundColor =[UIColor colorWithRed:0.0/255.0f green:140.0/255.0f blue:200.0/255.0f alpha:1.0];
	
	_title = [[UITextView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, _width, _height *.1)];
	[_title addObserver:self forKeyPath:@"contentSize" options:(NSKeyValueObservingOptionNew) context:NULL];
	
	_title.text = @"Simple banner integration";
	_title.backgroundColor = [UIColor whiteColor];
	_title.textColor = [UIColor darkGrayColor];
	_title.editable = NO;
	_title.textAlignment = NSTextAlignmentCenter;
	_title.font = [UIFont boldSystemFontOfSize:XScale * 24];
	
	[self addSubview:_title];
	
	UITextView * text_1 = [[UITextView alloc] initWithFrame:CGRectMake(0, _height * 0.15, _width, _height * 0.08)];
	[self createLabel:text_1 withText:@"Default Banner :"];
	
	UIView * banner_1 = [self addBanner:_height * 0.25 withWidth:0 withHeigh:0 withDisplay:false withOp:@""];
	banner_1.backgroundColor = [UIColor clearColor];
	
	UITextView * text_2 = [[UITextView alloc] initWithFrame:CGRectMake(0, _height * 0.40, _width, _height * 0.08)];
	[self createLabel:text_2 withText:@"Resized Banner :"];
	
	UIView * banner_2 = [self addBanner:_height * 0.50  withWidth:_width *.5 withHeigh:0 withDisplay:false withOp:@""];
	banner_2.backgroundColor = [UIColor clearColor];
	banner_2.center = CGPointMake(_width * 0.25, _height * 0.50);
	
	UITextView * text_3 = [[UITextView alloc] initWithFrame:CGRectMake(0, _height * 0.60, _width, _height * 0.08)];
	[self createLabel:text_3 withText:@"Closable Banner:"];
	
	UIView * banner_3 = [self addBanner:_height * 0.7 withWidth:_width *.75 withHeigh:0 withDisplay:true withOp:@""];
	banner_3.backgroundColor = [UIColor clearColor];
	banner_3.center = CGPointMake(_width * 0.1, _height * 0.7);
	
	UIButton * returnButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	returnButton.backgroundColor = [UIColor clearColor];
	[returnButton addTarget:self action:@selector(onClickReturnButton:) forControlEvents:UIControlEventTouchUpInside];
	[returnButton setFrame:CGRectMake(_width * 0.25,_height * 0.9 ,_width * 0.5, _height * 0.1)];
	[returnButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	returnButton.titleLabel.font = [UIFont systemFontOfSize: 24 * XScale];
	[returnButton setTitle:@"Return" forState:UIControlStateNormal];
	[self addSubview:returnButton];
	
}

/****************************************
 * BUILD VIEW (METHODS)
 ***************************************/

-(void)onClickReturnButton:(UIButton *) sender{
	
	[_title removeObserver:self forKeyPath:@"contentSize"];
	[self removeFromSuperview];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	
	UITextView *tv = object;
	CGFloat topCorrect = ([tv bounds].size.height - [tv contentSize].height * [tv zoomScale])/2.0;
	topCorrect = ( topCorrect < 0.0 ? 0.0 : topCorrect );
	tv.contentOffset = (CGPoint){.x = 0, .y = -topCorrect};
}

- (void) createLabel:(UITextView *)label withText:(NSString *)textLabel{
	
	label.text = textLabel;
	label.editable = NO;
	label.textColor = [UIColor whiteColor];
	label.textAlignment = NSTextAlignmentCenter;
	label.font = [UIFont boldSystemFontOfSize:15 * XScale];
	label.backgroundColor = [UIColor clearColor];
	[self addSubview:label];
}

- (UIView *) addBanner:(float)margin withWidth:(float)witdh withHeigh:(float)height withDisplay:(bool)isDiplay withOp:(NSString *)op {
	
	/****************************************
	 * BOX SDK INTEGRATION
	 ***************************************/
	
	//Displaying banner
	UIView * view =[Box getBannerViewWithID:op width:witdh height:height displayCloseButton:isDiplay];
	
	[self addSubview:view];
	view.backgroundColor = [UIColor blackColor];
	view.center = CGPointMake(0, margin);
	return view;
}

@end
