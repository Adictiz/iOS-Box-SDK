//
//  main.m
//  SampleProject
//
//  Created by Kévin LEFEBVRE on 01/12/2015.
//  Copyright © 2015 Kévin LEFEBVRE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
