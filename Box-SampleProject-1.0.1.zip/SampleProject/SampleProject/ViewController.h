//
//  ViewController.h
//  SampleProject
//
//  Created by Kévin LEFEBVRE on 01/12/2015.
//  Copyright © 2015 Kévin LEFEBVRE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Box/Box.h>
#import "BannerView.h"
#import "BannersListView.h"
#import "PostUserView.h"

@interface ViewController : UIViewController <BBoxRequestDelegate>

@property NSString * mediakey;
@property NSString * apikey;

@property BOOL isReady;
@property UIButton * buttonShowCampaign;
@property UIButton * buttonShowBanners;
@property UIButton * buttonShowBannersList;
@property UIButton * buttonShowUserPost;

@property NSString * campaignID;

@end

