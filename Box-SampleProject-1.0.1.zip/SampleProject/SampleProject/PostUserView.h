//
//  BannerView.h
//  Box
//
//  Created by Kévin LEFEBVRE on 13/04/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import "AppDelegate.h"
#import <Box/Box.h>

@interface PostUserView : UIView <BBoxRequestDelegate>

@property UITextView * title;
@property UITextView * firstName;
@property UITextView * lastName;
@property UITextView * email;
@property BUser * user;

@property UIButton * submit;
@property NSString * apiKey;
@property NSString * campaignID;

- (id) initWithOperation:(NSString *)operation withApiKey:(NSString *) apikey;
- (void) initialize;

@end
