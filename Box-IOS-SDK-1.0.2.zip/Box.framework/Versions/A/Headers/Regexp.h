//
//  Regexp.h
//  Box
//
//  Created by Kévin LEFEBVRE on 11/09/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RegExCategories.h"

@interface Regexp : NSObject

+ (BOOL) isStringIsValide:(NSString *) value;

+ (BOOL) isEmailIsValide:(NSString *)value;

+ (BOOL) isDateEUIsValide:(NSString *)value;

+ (BOOL) isDateUSIsValide:(NSString *)value;

+ (BOOL) isNumberIsValide:(NSString *)value;

@end
