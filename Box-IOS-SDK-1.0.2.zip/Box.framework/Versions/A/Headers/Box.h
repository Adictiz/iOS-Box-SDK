//
//  Box.h
//  Box
//
//  Created by Matthieu Karolewicz on 07/01/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BWebviewOptions.h"
#import "BUser.h"
#import "BPicture.h"

/**
 *  Defines supported banner positions
 */
typedef NS_ENUM(NSInteger, BBannerPosition){
    /**
     *  The banner will be top centered
     */
    BBannerPositionTop,
    /**
     *  The banner will be bottom centered
     */
    BBannerPositionBottom
};

static BOOL developmentMode = false;
static BOOL debugMode = false;

/**
 *  Delegate protocol to handle Box API requests
 */
@protocol BBoxRequestDelegate <NSObject>
@optional
/**
 *  Called when a getCampaignsList call succeeds
 *
 *  @param response NSString JSON encoded string containing the Box campaigns list
 */
- (void)onGetCampaignsListSuccess:(NSString *)response;
/**
 *  Called when a getCampaignsList call fails
 *
 *  @param error NSString containing the error description message
 */
- (void)onGetCampaignsListFailure:(NSString *)error;
/**
 * Called when a postUserForm call succeeds
 * @param userId NSString containing the user id
 */
- (void)onPostUserFormSuccess:(NSString *)userId;
/**
 * Called when a postUserForm call fails
 * @param error NSString containing the error message
 */
- (void)onPostUserFormFailure:(NSString *)error;
/**
 * Called when a postPicture  is called
 * @param isSuccess Bool containing the result of the request
 */
- (void)onPostPictureResult:(bool)isSuccess;

/**
 * Called when a getPictureList call succeeds
 * @param response NSString JSON encoded string containing the Box pictures list
 */
- (void)onGetPicturesListSuccess:(NSString *)response;

/**
 * Called when a getPictureList call fails
 * @param error NSString containing the error description message
 */
- (void)onGetPicturesListFailure:(NSString *) error;

@end

@interface Box : NSObject

+ (void)initialize:(NSString *)mediaKey;
+ (void)handleOpenURL:(NSURL *)url;
+ (void)getCampaignsList:(id<BBoxRequestDelegate>)delegate;
+ (void)postUserForm:(NSString *)apiKey withCampaignId:(NSString *) campaignId withBoxUser:(BUser *)user withDelegate:(id<BBoxRequestDelegate>)delegate;
+ (void)postPicture:(NSString *)apiKey withCampaignId:(NSString *) campaignId withBoxPicture:(BPicture *)picture withDelegate:(id<BBoxRequestDelegate>)delegate;
+ (void)getPicturesList:(NSString *)apiKey withCampaignId:(NSString *)campaignId withLimit:(int)limit withOffset:(int)offset withSort:(NSString *)sort withModerate:(bool)moderate withDelegate:(id<BBoxRequestDelegate>)delegate;
+ (void)getPicturesList:(NSString *)apiKey withCampaignId:(NSString *)campaignId withDelegate:(id<BBoxRequestDelegate>)delegate;
+ (void)showCampaign:(NSString *)campaignId withUIViewController:(UIViewController *) viewController;
+ (void)showCampaign:(NSString *)campaignId withBoxUser:(BUser *)user  withUIViewController:(UIViewController *) viewController;
+ (void)showBanner:(NSString *)mediaKey withUIViewController:(UIViewController *) viewController;;
+ (void)showBanner:(NSString *)mediaKey withPosition:(BBannerPosition)position withUIViewController:(UIViewController *) viewController;
+ (BWebviewOptions *)webviewOptions;
+ (void)setWebviewOptions:(BWebviewOptions *)options;
+ (BOOL)developmentMode;
+ (void)setDevelopmentMode:(BOOL)value;
+ (BOOL)debugMode;
+ (void)setDebugMode:(BOOL)value;
+ (UIView *)getCampaignsListView;
+ (UIView *)getCampaignsListViewWithWidth:(float)width height:(float)height;
+ (UIView *)getBannerViewWithID:(NSString *)campaignId width:(float)width height:(float)height displayCloseButton:(bool)isDisplay;
+ (UIView *)getBannerView;
+ (UIView *)getBannerViewWithID:(NSString *)campaignId;
+ (UIView *)getBannerViewWithID:(NSString *)campaignId width:(float)width height:(float)height;
+ (UIView *)getBannerViewWithDisplayCloseButton:(bool)isDisplay;
+ (UIView *)getBannerViewWithID:(NSString *)campaignId displayCloseButton:(bool)isDisplay;
+ (UIView *)getBannerViewWithWidth:(float)width height:(float)height displayCloseButton:(bool)isDisplay;
+ (UIView *)getBannerViewWithWidth:(float)width height:(float)height;

@end
