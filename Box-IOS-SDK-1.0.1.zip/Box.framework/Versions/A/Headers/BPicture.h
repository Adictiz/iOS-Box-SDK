//
//  BPicture.h
//  Box
//
//  Created by Kévin LEFEBVRE on 08/09/2015.
//  Copyright (c) 2015 Adictiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 *  Defines data picture format
 */
typedef NS_ENUM(NSInteger, BTypePicture){
	/**
	 *  The picture will be a url
	 */
	BTypePictureURL,
	/**
	 *  The picture will be a base64 format
	 */
	BTypePictureBase64
};

/**
 *
 */
@interface BPicture : NSObject

@property (nonatomic)  BTypePicture  type;
@property (nonatomic)  NSString * data ;
@property (nonatomic)  NSString * userId ;
@property (nonatomic) NSString * name ;
@property (nonatomic)  NSString * desc;


- (BTypePicture)getTypePicture;
- (NSString *)getData;
- (NSString *)getUserId;
- (NSString *)getName;
- (NSString *)getDescription;

- (void)setTypePicture:(BTypePicture)value;
- (void)setData:(NSString *)value;
- (void)setUserId:(NSString *)value;
- (void)setName:(NSString *)value;
- (void)setDescription:(NSString *)value;

- (id)initWithType:(BTypePicture)type withData:(NSString *)data withUserId:(NSString *)userId withName:(NSString *)name withDescription:(NSString *)description;
- (id)init;
@end